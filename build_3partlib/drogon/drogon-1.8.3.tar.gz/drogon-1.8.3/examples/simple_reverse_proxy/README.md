### An example that shows how to use drogon as an http reverse proxy with a simple round robin.

This project is created with the drogon_ctl command, please compile it after installing drogon.